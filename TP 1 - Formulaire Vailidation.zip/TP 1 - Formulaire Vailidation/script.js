const nom = document.getElementById('name'), pseudo = document.getElementById('nickname'), notice_pwd = document.getElementById('notice'), mail = document.getElementById('email'), password = document.getElementById('pwd'), name_v = document.getElementById('name_val'), pseudo_v = document.getElementById('pseudo_val'), mail_v = document.getElementById('mail_val'), pwd_v = document.getElementById('pwd_val'), name_checker = /^[a-zA-Z][a-zéèâäïîëêç]+([-'\s][a-zA-Z][a-zéèâäïîëêç]+)([-'\s][a-zA-Z][a-zéèâäïîëêç]+)?/, pseudo_checker = /^[a-zA-Z][a-z0-9éèâäïîëêç#]+/, mail_checker = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w+)+$/, password_checker = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[-+!*$@#%_])([-+!*#$@%_\w]{8,30})$/;

nom.addEventListener('input', ({target: {value}}) => {
    if(name_checker.test(nom.value) == false){
        name_v.innerHTML = "<img src='Images/wrong.png' alt ='Wrong' />"
    }
    else{
        name_v.innerHTML = "<img src='Images/checked-symbol.png' alt ='Success' />";
    }
})

pseudo.addEventListener('input', ({target: {value}}) => {
    if(pseudo_checker.test(pseudo.value) == false){
        pseudo_v.innerHTML = "<img src='Images/wrong.png' alt ='Wrong' />"
    }
    else{
        pseudo_v.innerHTML = "<img src='Images/checked-symbol.png' alt ='Success' />";
    }
})

mail.addEventListener('input', ({target: {value}}) => {
    if(mail_checker.test(mail.value) == false){
        mail_v.innerHTML = "<img src='Images/wrong.png' alt ='Wrong' />"
    }
    else{
        mail_v.innerHTML = "<img src='Images/checked-symbol.png' alt ='Success' />";
    }
})

password.addEventListener('input', ({target: {value}}) => {
    if(password_checker.test(password.value) == false){
        pwd_v.innerHTML = "<img src='Images/wrong.png' alt ='Wrong' />";
        notice_pwd.style.display = 'inline';
    }
    else{
        pwd_v.innerHTML = "<img src='Images/checked-symbol.png' alt ='Success' />";
    }
})

